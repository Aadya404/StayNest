import os
import zipfile

def create_zip(source_dir, output_filename):
    print(f"Packaging {source_dir} into {output_filename}...")
    with zipfile.ZipFile(output_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(source_dir):
            if '__pycache__' in root or '.git' in root or '.gemini' in root:
                continue
            for file in files:
                if file.endswith('.pyc') or file == os.path.basename(output_filename) or file == 'create_zip.py':
                    continue
                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, source_dir)
                zipf.write(file_path, arcname)
    print(f"Done! Created '{output_filename}'.")

if __name__ == '__main__':
    create_zip(r'c:\DBS', r'c:\DBS\StayNest.zip')
